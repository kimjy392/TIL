> 공지
>> 실습 문제 소스를 순서대로 폴더별로 보기 좋게 정리해서 업로드 해주세요.

>> 풀지 못한 문제들은 파일명에 명시해주길 바랍니다.

>> 실습 문제에 대한 소스가 Git에 없으면 과제 미제출로 판단합니다.

---------------------------------------------------------

> 추가 문제

일자     |       문제         |출처         | 기타
---------|--------------------|-------------|----------
8월 29일 |5789.현주의상자바꾸기|SWEA          |IM 대비
8월 29일 |2007.패턴마디의길이|SWEA          |IM 대비
8월 29일 |1979.어디에단어가들어갈수있을까|SWEA          |IM 대비
8월 29일 |5356.의석이의세로로말해요|SWEA   |IM 대비
8월 29일 |2805.농작물수확하기|SWEA          |IM 대비
8월 29일 |1974.스도쿠검증|SWEA          |IM 대비
8월 29일 |1493.수의새로운연산|SWEA          |IM 대비
8월 27일 |[2597.줄자접기][BOJ2597]| BOJ     | IM 대비
8월 27일 |[2615.오목][BOJ2615]| BOJ     | IM 대비
8월 22일 |[2628.종이자르기][BOJ2628]| BOJ     | IM 대비
8월 22일 |5432.쇠막대기 자르기| SWEA        | 
8월 16일 |[1244.스위치 켜고 끄기][BOJ1244]  | BOJ      | IM 대비
8월 16일 |4408.자기 방으로 돌아가기| SWEA   |
8월 08일 |[10163.색종이][BOJ10163]| BOJ     | IM 대비
8월 08일 |[10815.숫자카드][BOJ10815]| BOJ   | 
8월 07일 |[2578.빙고][BOJ2578]| BOJ         | IM 대비
8월 07일 |4012. 요리사        | SWEA        | 

[BOJ2597]: https://www.acmicpc.net/problem/2597
[BOJ2615]: https://www.acmicpc.net/problem/2615
[BOJ2628]: https://www.acmicpc.net/problem/2628
[BOJ1244]: https://www.acmicpc.net/problem/1244
[BOJ2578]: https://www.acmicpc.net/problem/2578
[BOJ10163]: https://www.acmicpc.net/problem/10163
[BOJ10815]: https://www.acmicpc.net/problem/10815


----------------------------------------

> A형 보충수업

일자     |       문제         |출처         | 기타
---------|--------------------|------------|----------
8월 26일 |[2309.일곱난쟁이][BOJ2309]    |BOJ   |
8월 26일 |[1759.암호만들기][BOJ1759]     |BOJ   |
8월 26일 |N-Queen                      |SWEA  |
8월 26일 |[1697.숨바꼭질][BOJ1697]     |BOJ   |
8월 26일 |[2589.보물섬][BOJ2589]            |BOJ   |
8월 26일 |[2468.안전영역][BOJ2468]      |BOJ  |
8월 26일 |[5427.불][BOJ5427]           |BOJ   
8월 26일 |1873.상호의 배틀필드           |SWEA |


[BOJ2309]: https://www.acmicpc.net/problem/2309
[BOJ1759]: https://www.acmicpc.net/problem/1759
[BOJ3980]: https://www.acmicpc.net/problem/3980
[BOJ1697]: https://www.acmicpc.net/problem/1697
[BOJ6603]: https://www.acmicpc.net/problem/6603
[BOJ2589]: https://www.acmicpc.net/problem/2589
[BOJ2468]: https://www.acmicpc.net/problem/2468
[BOJ5427]: https://www.acmicpc.net/problem/5427




일자     |       문제         |출처         | 기타
---------|--------------------|-------------|----------
8월 21일 |[1260.DFS와 BFS][BOJ1260]         |BOJ     |
8월 21일 |[11724.연결요소의 개수][BOJ11724] |BOJ|DFS연습
8월 21일 |[2667.단지번호붙이기][BOJ2667]    |BOJ| DFS연습
8월 21일 |[2178.미로탐색][BOJ2178]          |BOJ| BFS연습
8월 21일 |[2206.벽부수고 이동하기][BOJ2206] |BOJ|BFS연습


[BOJ1260]: https://www.acmicpc.net/problem/1260
[BOJ11724]: https://www.acmicpc.net/problem/11724
[BOJ2667]: https://www.acmicpc.net/problem/2667
[BOJ2178]: https://www.acmicpc.net/problem/2178
[BOJ2206]: https://www.acmicpc.net/problem/2206
