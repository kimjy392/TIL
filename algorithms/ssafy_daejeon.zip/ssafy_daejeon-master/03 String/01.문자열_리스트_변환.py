STR1 = 'algorithm'

LIST = list(STR1)
print(LIST)

STR2 = ''.join(LIST)

print(STR2)

