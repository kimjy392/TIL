#문자열 뒤집기

arr = 'algorithm'
arr = arr[::-1]

print(arr)

arr = arr[::-1]

print(arr)
