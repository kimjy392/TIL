### 연결 리스트 실습

> 실습 순서

```
- LinkedList.py의 List 클래스에 다음 메소드를 작성한다.
 
    1. printlist() 작성
    2. insertlast() 작성
    3. insertfirst() 작성
    4. deletelast() 작성
    5. deletefirst() 작성
    6. insertAt() 작성
    7. deleteAt() 작성
```