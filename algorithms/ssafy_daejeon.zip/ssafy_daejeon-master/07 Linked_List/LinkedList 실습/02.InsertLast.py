from LinkedList import List, Node
print('02.insertlast()_____________\n')
# ------------------------------------------------

mylist = List()
mylist.insertlast(Node(1))
mylist.insertlast(Node(2))
mylist.insertlast(Node(3))
mylist.insertlast(Node(4))
mylist.insertlast(Node(5))
mylist.printlist()